from django.contrib import admin
from appcrypt.models import TestModel

# Register your models here.
admin.site.register(TestModel)