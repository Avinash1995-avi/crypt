from django.db import models
from django_cryptography.fields import encrypt
from encrypted_model_fields.fields import EncryptedCharField
# Create your models here.

class TestModel(models.Model):
    name=models.CharField(max_length=60)
    sensitive_data = encrypt(models.CharField(max_length=60))
    dcrypt = models.IntegerField(default=1)
    scrypt = encrypt(models.EmailField(default='abc.@gmail.com'))
    realencrypt = EncryptedCharField(max_length=20)

    def __str__(self):
        return self.name

