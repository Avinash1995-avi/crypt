from django.apps import AppConfig


class AppcryptConfig(AppConfig):
    name = 'appcrypt'
